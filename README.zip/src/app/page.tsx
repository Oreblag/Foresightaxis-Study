import React from "react";
// import { motion } from "framer-motion";
import { FramerWrapper } from "@/components/FramerWrapper"
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CheckCircle2, BookOpen, GraduationCap, Users, Award, Globe2, PlayCircle, ArrowRight, Shield, Sparkles, TrendingUp } from "lucide-react";

// Landing page for an education website inspired by hizo.africa's clean, bold, modern aesthetic.
// TailwindCSS required. shadcn/ui, lucide-react, and framer-motion are used for polish.
// Drop this in a Next.js app under app/page.tsx or src/app/page.tsx and ensure Tailwind is configured.

const stats = [
  { label: "Learners", value: "120k+" },
  { label: "Courses", value: "950+" },
  { label: "Instructors", value: "1.2k+" },
  { label: "Countries", value: "35+" },
];

const features = [
  {
    icon: <BookOpen className="h-6 w-6" />, 
    title: "Industry‑Ready Curricula",
    desc: "Project‑based learning co-created with employers so you graduate job‑ready.",
  },
  {
    icon: <Users className="h-6 w-6" />, 
    title: "Mentors & Community",
    desc: "Weekly mentor sessions, peer groups, and 24/7 discussion spaces.",
  },
  {
    icon: <Award className="h-6 w-6" />, 
    title: "Micro‑Credentials",
    desc: "Stackable certificates mapped to global skills frameworks.",
  },
  {
    icon: <Globe2 className="h-6 w-6" />, 
    title: "Hybrid & Flexible",
    desc: "Study live or self‑paced on any device with offline notes and mobile‑first UX.",
  },
];

const programs = [
  {
    title: "Data & Analytics",
    level: "Beginner → Advanced",
    bullets: ["Excel to SQL", "Power BI & Tableau", "Python Data Science"],
  },
  {
    title: "Cloud & DevOps",
    level: "Career Switch",
    bullets: ["AWS & Azure", "Docker & Kubernetes", "CI/CD & Terraform"],
  },
  {
    title: "Product & Design",
    level: "Beginner",
    bullets: ["Product Management", "UX/UI with Figma", "Design Systems"],
  },
];

const partners = [
  "Microsoft", "Google", "AWS", "Meta", "Andela", "Flutterwave",
];

const fadeUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.6 },
};

export default function EduLanding() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 via-white to-slate-50 text-slate-900">
      {/* Nav */}
      <header className="sticky top-0 z-40 backdrop-blur bg-white/70 border-b border-slate-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-2">
              <div className="h-9 w-9 rounded-2xl bg-gradient-to-br from-indigo-500 to-fuchsia-500 grid place-items-center">
                <Sparkles className="h-5 w-5 text-white" />
              </div>
              <span className="font-semibold tracking-tight">EduConnect Africa</span>
            </div>
            <nav className="hidden md:flex items-center gap-6 text-sm">
              <a className="hover:text-indigo-600" href="#programs">Programs</a>
              <a className="hover:text-indigo-600" href="#features">Features</a>
              <a className="hover:text-indigo-600" href="#partners">Partners</a>
              <a className="hover:text-indigo-600" href="#faq">FAQ</a>
            </nav>
            <div className="flex items-center gap-3">
              <Button variant="ghost" className="hidden sm:inline-flex">Sign in</Button>
              <Button className="bg-indigo-600 hover:bg-indigo-700 rounded-2xl px-4">Get started</Button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 pointer-events-none [mask-image:radial-gradient(ellipse_at_center,black,transparent_70%)]">
          <div className="absolute -top-24 -left-24 h-72 w-72 rounded-full bg-fuchsia-300/30 blur-3xl" />
          <div className="absolute -bottom-24 -right-24 h-72 w-72 rounded-full bg-indigo-300/30 blur-3xl" />
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-24">
          <div className="grid md:grid-cols-2 gap-10 md:gap-16 items-center">
          <FramerWrapper initial={fadeUp.initial} animate={fadeUp.animate} transition={fadeUp.transition}>
          <span className="inline-flex items-center gap-2 rounded-full border bg-white/80 px-3 py-1 text-xs font-medium text-slate-700 shadow-sm">
            <Shield className="h-3.5 w-3.5" /> ISO‑aligned courses • Employer‑reviewed
          </span>
          <h1 className="mt-4 text-4xl md:text-6xl font-semibold leading-tight tracking-tight">
            Build job‑ready skills with Africa’s
            <span className="bg-gradient-to-r from-indigo-600 to-fuchsia-600 bg-clip-text text-transparent"> leading online academy</span>
          </h1>
          <p className="mt-5 text-slate-600 text-lg max-w-xl">
            Learn in live cohorts or self‑paced. Earn micro‑credentials and get matched to internships and roles across the continent.
          </p>
          <div className="mt-6 flex flex-col sm:flex-row gap-3">
            <div className="flex-1 min-w-[240px]">
              <Input placeholder="Search courses e.g. Data, Cloud, Product…" className="h-11 rounded-2xl bg-white/90 border-slate-200" />
            </div>
            <Button className="h-11 rounded-2xl bg-indigo-600 hover:bg-indigo-700 px-5">
              Explore programs <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
          <div className="mt-8 grid grid-cols-2 sm:grid-cols-4 gap-4">
            {stats.map((s, i) => (
              <Card key={i} className="rounded-2xl border-slate-200">
                <CardContent className="p-4">
                  <div className="text-2xl font-semibold">{s.value}</div>
                  <div className="text-xs text-slate-500">{s.label}</div>
                </CardContent>
              </Card>
            ))}
          </div>
        </FramerWrapper>

        <FramerWrapper
          className="relative"
          initial={{ opacity: 0, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6, delay: 0.1 }}
        >
          <div className="aspect-[4/3] rounded-3xl bg-gradient-to-br from-indigo-50 to-fuchsia-50 border border-slate-200 overflow-hidden shadow-sm">
            <div className="absolute inset-0 grid grid-cols-3 gap-2 p-4">
              {[...Array(9)].map((_, i) => (
                <div key={i} className="rounded-xl bg-white/70 border border-slate-100 backdrop-blur p-3 flex flex-col justify-between">
                  <div className="text-sm font-medium">Module {i + 1}</div>
                  <div className="text-[10px] text-slate-500">Lessons • Projects • Quiz</div>
                </div>
              ))}
            </div>
            <button className="absolute bottom-4 left-4 inline-flex items-center gap-2 bg-white/90 rounded-full px-4 py-2 text-sm shadow border">
              <PlayCircle className="h-4 w-4" /> Watch demo class
            </button>
          </div>
        </FramerWrapper>
          </div>
        </div>
      </section>

      {/* Partner bar */}
      <section id="partners" className="py-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center text-sm text-slate-500 mb-4">Trusted by teams at</div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-4 items-center">
            {partners.map((p) => (
              <div key={p} className="h-12 rounded-2xl border border-slate-200 bg-white grid place-items-center text-slate-500 text-sm">
                {p}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="py-14 md:py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl">
            <h2 className="text-3xl md:text-4xl font-semibold tracking-tight">Everything you need to learn and get hired</h2>
            <p className="mt-3 text-slate-600">Modern platform, African context, global standards.</p>
          </div>
          <div className="mt-8 grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {features.map((f, i) => (
              <Card key={i} className="rounded-2xl border-slate-200">
                <CardHeader className="pb-2">
                  <CardTitle className="text-base flex items-center gap-2">
                    <span className="inline-flex h-9 w-9 rounded-xl border bg-slate-50 items-center justify-center">
                      {f.icon}
                    </span>
                    {f.title}
                  </CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-slate-600">{f.desc}</CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Programs */}
      <section id="programs" className="py-16 bg-gradient-to-b from-white to-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-end justify-between gap-4 flex-wrap">
            <div>
              <h2 className="text-3xl md:text-4xl font-semibold tracking-tight">Popular programs</h2>
              <p className="text-slate-600 mt-2">Cohort‑based and self‑paced tracks designed with employers.</p>
            </div>
            <Button variant="outline" className="rounded-2xl">View all</Button>
          </div>
          <div className="mt-8 grid md:grid-cols-3 gap-5">
            {programs.map((p) => (
              <Card key={p.title} className="rounded-2xl border-slate-200 hover:shadow-md transition-shadow">
                <CardHeader>
                  <CardTitle className="text-xl flex items-center gap-2">
                    <GraduationCap className="h-5 w-5" /> {p.title}
                  </CardTitle>
                  <div className="text-xs text-slate-500">{p.level}</div>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 text-sm text-slate-700">
                    {p.bullets.map((b) => (
                      <li key={b} className="flex items-start gap-2">
                        <CheckCircle2 className="h-4 w-4 shrink-0" />
                        <span>{b}</span>
                      </li>
                    ))}
                  </ul>
                  <div className="mt-4 flex items-center justify-between">
                    <div className="inline-flex items-center text-sm text-slate-500">
                      <TrendingUp className="h-4 w-4 mr-1" /> High demand
                    </div>
                    <Button className="rounded-xl h-9 px-4">Enroll</Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Banner */}
      <section className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="relative overflow-hidden rounded-3xl border border-slate-200 bg-gradient-to-r from-indigo-600 to-fuchsia-600 text-white p-8 md:p-12 shadow">
            <div className="absolute inset-0 opacity-20 bg-[radial-gradient(circle_at_20%_20%,white,transparent_30%),radial-gradient(circle_at_80%_0%,white,transparent_30%)]" />
            <div className="relative grid md:grid-cols-2 gap-8 items-center">
              <div>
                <h3 className="text-2xl md:text-3xl font-semibold">Scholarships for women & youth in tech</h3>
                <p className="mt-2 text-white/90">Apply for up to 80% tuition support through our partner network.</p>
                <div className="mt-5 flex gap-3">
                  <Button className="bg-white text-slate-900 hover:bg-white/90 rounded-2xl">Apply now</Button>
                  <Button variant="secondary" className="bg-white/10 text-white hover:bg-white/20 rounded-2xl">Learn more</Button>
                </div>
              </div>
              <ul className="grid gap-3 text-sm">
                {[
                  "Rolling admissions with monthly start dates",
                  "Career services: CV, interview prep, job matching",
                  "Internships with regional partners",
                ].map((t) => (
                  <li key={t} className="inline-flex items-start gap-2">
                    <CheckCircle2 className="h-4 w-4 mt-0.5" /> {t}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section id="faq" className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl md:text-4xl font-semibold tracking-tight text-center">Frequently asked questions</h2>
          <div className="mt-8 grid gap-4">
            {[
              {
                q: "Are classes live or self‑paced?",
                a: "Both. Join live cohorts for accountability, or learn self‑paced with mentor support.",
              },
              {
                q: "Do you provide certificates?",
                a: "Yes. You earn verifiable micro‑credentials mapped to global skills frameworks.",
              },
              {
                q: "How does career support work?",
                a: "We offer interview prep, CV reviews, portfolio clinics, and introductions to partner employers.",
              },
            ].map((item, idx) => (
              <Card key={idx} className="rounded-2xl border-slate-200">
                <CardHeader>
                  <CardTitle className="text-lg">{item.q}</CardTitle>
                </CardHeader>
                <CardContent className="text-slate-600">{item.a}</CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-200 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center gap-2">
                <div className="h-9 w-9 rounded-2xl bg-gradient-to-br from-indigo-500 to-fuchsia-500 grid place-items-center">
                  <Sparkles className="h-5 w-5 text-white" />
                </div>
                <span className="font-semibold">EduConnect Africa</span>
              </div>
              <p className="mt-3 text-sm text-slate-600">Accessible, employment‑focused learning for Africa.</p>
            </div>
            <div>
              <div className="font-medium mb-3">Programs</div>
              <ul className="space-y-2 text-sm text-slate-600">
                <li>Data & Analytics</li>
                <li>Cloud & DevOps</li>
                <li>Product & Design</li>
                <li>Cybersecurity</li>
              </ul>
            </div>
            <div>
              <div className="font-medium mb-3">Company</div>
              <ul className="space-y-2 text-sm text-slate-600">
                <li>About</li>
                <li>Careers</li>
                <li>Partners</li>
                <li>Contact</li>
              </ul>
            </div>
            <div>
              <div className="font-medium mb-3">Resources</div>
              <ul className="space-y-2 text-sm text-slate-600">
                <li>Blog</li>
                <li>Help Center</li>
                <li>Scholarships</li>
                <li>Terms & Privacy</li>
              </ul>
            </div>
          </div>
          <div className="mt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
            <div>© {new Date().getFullYear()} EduConnect Africa. All rights reserved.</div>
            <div className="inline-flex items-center gap-3">
              <span className="inline-flex items-center gap-1"><Shield className="h-3.5 w-3.5" /> GDPR Ready</span>
              <span className="inline-flex items-center gap-1"><BookOpen className="h-3.5 w-3.5" /> Open Courses</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
